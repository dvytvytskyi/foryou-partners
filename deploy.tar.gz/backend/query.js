const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const notifs = await prisma.notification.findMany({ orderBy: { createdAt: 'desc' }, take: 5 });
  console.log(notifs);
}
main().catch(console.error).finally(() => prisma.$disconnect());
