'use client';

import React, { useEffect, useState, useRef } from 'react';
import { Search, X, Command, User, Briefcase, Settings, ArrowRight } from 'lucide-react';
import styles from './SpotlightSearch.module.css';

interface SpotlightSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES = ['All', 'Leads', 'Partners', 'Actions', 'Help'];

const MOCK_RESULTS = [
  { id: '1', type: 'lead', title: 'Savannah Nguyen', subtitle: 'Dubai Marina • $1,250,000', icon: User },
  { id: '2', type: 'lead', title: 'Jerome Bell', subtitle: 'Palm Jumeirah • $450,000', icon: User },
  { id: '3', type: 'partner', title: 'Elite Real Estate', subtitle: 'Active • 148 leads', icon: Briefcase },
  { id: '4', type: 'action', title: 'Add New Lead', subtitle: 'Quick shortcut', icon: ArrowRight },
  { id: '5', type: 'setting', title: 'Notification Settings', subtitle: 'System preferences', icon: Settings },
];

export function SpotlightSearch({ isOpen, onClose }: SpotlightSearchProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev < MOCK_RESULTS.length - 1 ? prev + 1 : prev));
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev > 0 ? prev - 1 : prev));
      }
      if (e.key === 'Enter') {
        // Handle selection
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const filteredResults = MOCK_RESULTS.filter(res => 
    res.title.toLowerCase().includes(query.toLowerCase()) || 
    res.type.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        <div className={styles.searchRow}>
          <Search className={styles.searchIcon} size={20} />
          <input
            ref={inputRef}
            type="text"
            className={styles.input}
            placeholder="Search everything..."
            value={query}
            onChange={e => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
          />
          <div className={styles.closeBtn} onClick={onClose}>
            <X size={18} />
          </div>
        </div>

        <div className={styles.categoriesRow}>
          {CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`${styles.categoryBtn} ${activeCategory === cat ? styles.categoryBtnActive : ''}`}
            >
              {cat}
            </button>
          ))}
        </div>
        
        <div className={styles.results}>
          {filteredResults.length > 0 ? (
            <div className={styles.resultsList}>
              {filteredResults.map((result, index) => (
                <div 
                  key={result.id}
                  className={`${styles.resultItem} ${index === selectedIndex ? styles.resultItemActive : ''}`}
                  onMouseEnter={() => setSelectedIndex(index)}
                  onClick={onClose}
                >
                  <div className={`${styles.resultIcon} ${styles[result.type]}`}>
                    <result.icon size={16} />
                  </div>
                  <div className={styles.resultInfo}>
                    <div className={styles.resultTitle}>{result.title}</div>
                    <div className={styles.resultSubtitle}>{result.subtitle}</div>
                  </div>
                  {index === selectedIndex && (
                    <div className={styles.enterHint}>
                      <span>Enter</span>
                      <ArrowRight size={12} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className={styles.noResults}>
              No results found for "{query}"
            </div>
          )}
        </div>

        <div className={styles.footer}>
          <div className={styles.footerLeft}>
            <div className={styles.key}>↑↓</div>
            <span>to navigate</span>
            <div className={styles.key} style={{ marginLeft: '12px' }}>Enter</div>
            <span>to select</span>
            <div className={styles.key} style={{ marginLeft: '12px' }}>Esc</div>
            <span>to close</span>
          </div>
        </div>
      </div>
    </div>
  );
}
