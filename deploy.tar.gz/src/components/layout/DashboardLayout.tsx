'use client';

import React from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { PageHeader } from './PageHeader';
import { useAuthStore } from '@/lib/stores/auth.store';
import { usePathname } from 'next/navigation';
import styles from './DashboardLayout.module.css';

interface DashboardLayoutProps {
  children: React.ReactNode;
  dict: any;
}

export function DashboardLayout({ children, dict }: DashboardLayoutProps) {
  const pathname = usePathname();
  const user = useAuthStore((state) => state.user);
  const isKlykovUser = user?.email?.toLowerCase().includes('klykov') ?? false;

  return (
    <div className={styles.layoutWrapper}>
      {!isKlykovUser && <Sidebar dict={dict.sidebar} />}
      <div className={styles.mainContent}>
        <Header dict={dict.header} />
        <PageHeader dict={dict.page_header} />
        <main className={styles.pageBody}>
          {children}
        </main>
      </div>
    </div>
  );
}
